import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-200 to-blue-500 text-white p-8 flex flex-col justify-center items-center text-center">
      <h1 className="text-4xl font-extrabold mb-4 drop-shadow-lg">Neuronest: ADA Letter Generator</h1>
      <p className="text-lg max-w-xl mb-6">
        Empower yourself with AI to generate legally accurate ADA complaint letters in minutes. Built with accessibility in mind — simple, fast, and reliable.
      </p>
      <Link href="/form">
        <Button className="text-lg px-6 py-3 rounded-2xl shadow-md">Start Generating</Button>
      </Link>
      <div className="mt-10 text-sm text-white/80">
        <p>Created by Jeramiah Brown · ADA & Disability Rights Advocate</p>
      </div>
    </div>
  );
}
